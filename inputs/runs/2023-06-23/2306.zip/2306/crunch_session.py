#! /usr/bin/env python3

from pylab import *
from glob import glob
from statistics import stdev
from scipy.stats import norm as normal_dist
from scipy.special import erfinv
from allantools import oadev as adev
from matplotlib import ticker

REJECTION_TRESHOLD = 0.2 # PERMIL

IGNORE_FIRST = 0

T_MIN = -1
T_MAX = 27.3

TIME_FIELD_NAME = 't'
PRESSURE_FIELD_NAME = 'P'
SAMPLE_FIELD_NAME = 'SampName'
REPLACE_626_WITH_626b = False
ISO_COLORS = {
	'626': (0, 0, 0,),
	'626b': (0.5, 0.5, 0.5,),
	'636': (0, .5, 0),
# 	'636b': (.5, .75, 0),
	'628': (.9, 0, 0),
	'627': (.9, 0, .5),
}

SAMPLE_NAME_REPLACEMENTS = {
 #	'Carrare': 'BIPM1',
# 	'P20467': 'BIPM_3',
# 	'P20466': 'BIPM_1',
# 	'P20468': 'BIPM_2',
# 	'P20465': 'BIPM_4',
# 	'IAEA603': 'IAEA_603',
# 	'IAEA610': 'IAEA_610',
# 	'IAEA611': 'IAEA_611',
# 	'IAEA612': 'IAEA_612',
	'WG': 'OLD_WG',
	'Ref Bottle': 'WG',
}

def is_outlier(X, absmax = REJECTION_TRESHOLD, zmax = 4):
	r = abs(X - median(X)) # absolute deviation
	if absmax: return r > absmax
	f = sqrt(2) * erfinv(.5) # estimator of median(r)
	z = f * r / median(r) # modified z-score
	return z > zmax

# READ DATA FILE
with open(glob('data/*.dat')[0]) as f:
	data = [[x.strip() for x in l.split('\t')] for l in f.readlines()]
data = [{k:float(v) if k != SAMPLE_FIELD_NAME else v for k,v in zip(data[0], l)} for l in data[1:] if l[4].lower() != 'nan']

# data = [r for r in data if r['627'] > 0.95]

for r in data:
	if REPLACE_626_WITH_626b:
		r['626'] = r['626b']
# 	print(r)

# DEFINE TIME AS HOURS FROM START OF DATA
t0 = data[0]['t']
for r in data:
	r['t'] -= t0
	r['t'] *= 24

data = [r for r in data if r['t'] > T_MIN and r['t'] < T_MAX]

# CONVERT P TO MBAR
for r in data:
	try:
		r['P'] *= 1.33322
	except KeyError:
		r['P'] = 10.

# CLEAN UP SAMPLE NAMES
for r in data:
	if r[SAMPLE_FIELD_NAME] in SAMPLE_NAME_REPLACEMENTS:
		r['Sample'] = SAMPLE_NAME_REPLACEMENTS[r[SAMPLE_FIELD_NAME]]
	else:
		r['Sample'] = r[SAMPLE_FIELD_NAME]

# COMPUTE DELTA VALUES
for r in data:
	for k,i in enumerate(ISO_COLORS):
		if k == 0:
			j = i
		else:
			r['d'+i] = (r[i] / r[j] - 1) * 1e3

# for r in data: print(r)

# BUILD BLOCKS
blocks = []
last_sample = ''
for r in data:
	if r['Sample'] != last_sample:

		# CREATE NEW BLOCK
		blocks.append({})
		blocks[-1]['Sample'] = r['Sample']
		blocks[-1]['_t'] = []
		blocks[-1]['_P'] = []
		for k,i in enumerate(ISO_COLORS):
			blocks[-1]['_'+i] = []
			if k > 0:
				blocks[-1]['_d'+i] = []

	# FILL CURRENT BLOCK
	for k in 'tP':
		blocks[-1]['_'+k].append(r[k])
	for k,i in enumerate(ISO_COLORS):
		blocks[-1]['_'+i].append(r[i])
		if k > 0:
			blocks[-1]['_d'+i].append(r['d'+i])

	last_sample = r['Sample']

blocks = blocks[:((len(blocks)-1)//2)*2+1]

# PROCESS OUTLIERS AND MEANS
for b in blocks:

	# IDENTIFY OUTLIERS
	reject = [False for x in b['_t']]
	for k,i in enumerate(ISO_COLORS):
		if k > 0:
			reject = logical_or(reject, is_outlier(b['_d'+i]))

	# REJECT OUTLIERS
	for k in 'tP':
		b['rejected_'+k] = array(b['_'+k])[reject]
		b['_'+k] = array(b['_'+k])[logical_not(reject)]
	for k,i in enumerate(ISO_COLORS):
		b['rejected_'+i] = array(b['_'+i])[reject]
		b['_'+i] = array(b['_'+i])[logical_not(reject)]
		if k > 0:
			b['rejected_d'+i] = array(b['_d'+i])[reject]
			b['_d'+i] = array(b['_d'+i])[logical_not(reject)]

	# COMPUTE BLOCK MEANS
	for k in 'tP':
		b[k] = mean(b['_'+k][IGNORE_FIRST:])
	for k,i in enumerate(ISO_COLORS):
		b[i] = mean(b['_'+i][IGNORE_FIRST:])
		if k > 0:
			b['d'+i] = mean(b['_d'+i][IGNORE_FIRST:])

# NORMALIZE TO WG AVERAGE
for k,i in enumerate(ISO_COLORS):
	if k > 0:
		wgdi = mean([b['d'+i] for b in blocks if b['Sample'] == 'WG'])
		for b in blocks:
			b['d'+i] = ((1000 + b['d'+i])/(1000 + wgdi) - 1) * 1e3
			b['_d'+i] = ((1000 + b['_d'+i])/(1000 + wgdi) - 1) * 1e3
			b['rejected_d'+i] = ((1000 + b['rejected_d'+i])/(1000 + wgdi) - 1) * 1e3


# NORMALIZE TO LOCAL WG
for k,i in enumerate(ISO_COLORS):
	if k > 0:
		for j,b in enumerate(blocks):
			if b['Sample'] == 'WG':
				wgdi = b['d'+i]
			else:
				wgdi = (blocks[j-1]['d'+i] + blocks[j+1]['d'+i])/2
			b['d'+i+'_di'] = ((1000 + b['d'+i])/(1000 + wgdi) - 1) * 1e3
			b['_d'+i+'_di'] = ((1000 + b['_d'+i])/(1000 + wgdi) - 1) * 1e3
			b['rejected_d'+i+'_di'] = ((1000 + b['rejected_d'+i])/(1000 + wgdi) - 1) * 1e3



with open('crunched.csv', 'w') as fid:
	fid.write('Sample')
	for k,i in enumerate(ISO_COLORS):
		if k > 0:
			fid.write(f',d{i}_vswg,d{i}_vswg_di')
	for b in blocks:
		if b['Sample'] != 'WG':
			fid.write(f"\n{b['Sample']}")
			for k,i in enumerate(ISO_COLORS):
				if k > 0:
					fid.write(f",{b['d'+i]:.6f},{b['d'+i+'_di']:.6f}")

with open('crunched_all.csv', 'w') as fid:
	fid.write('Sample')
	for k,i in enumerate(ISO_COLORS):
		if k > 0:
			fid.write(f',d{i}_vswg,d{i}_vswg_di')
	for b in blocks:
		if b['Sample'] != 'WG':
			for t in range(len(b['_t'])):
				fid.write(f"\n{b['Sample']}")
				for k,i in enumerate(ISO_COLORS):
					if k > 0:
						fid.write(f",{b['_d'+i][t]:.6f},{b['_d'+i+'_di'][t]:.6f}")
			


fig = figure(figsize = (15,8))
subplots_adjust(hspace = 0)
ax_p = subplot(8,1,2)
ax_c = subplot(4,1,2, sharex = ax_p)
ax_d = subplot(4,1,3, sharex = ax_p)
ax_di = subplot(4,1,4, sharex = ax_p)

sca(ax_p)
ylabel('P (mbar)')
grid(alpha = .2)
X = [r['t'] for r in data]
Y = [r['P'] for r in data]
plot(X, Y, '+', ms = 4, mew = 1, mec = (.5, .5, .5))

sca(ax_c)
ylabel('concentration')
grid(alpha = .2)
for i in ISO_COLORS:
	X = [r['t'] for r in data]
	Y = [r[i] for r in data]
	plot(X, Y, '+', ms = 4, mec = ISO_COLORS[i], mew = 1, label = i)
legend()

sca(ax_d)
ylabel('delta vs WG (‰)')
grid(alpha = .2)
for k,i in enumerate(ISO_COLORS):
	if k > 0:
		for b in blocks:
			X = b['_t']
			Y = b['_d'+i]
			plot(X, Y, '+', ms = 4, mec = ISO_COLORS[i], mew = 1)

			X = b['rejected_t']
			Y = b['rejected_d'+i]
			plot(X, Y, 'x', ms = 4, mec = 'k', mew = 1, zorder = -100)

	for b in blocks:
		X = b['_t']
		Y = (log(1+b['_d627']/1e3) - 0.528*log(1+b['_d628']/1e3))*1000
# 		plot(X, Y, 's', ms = 4, mec = 'k', mew = 1)
		plot(mean(X), mean(Y), 'ks', ms = 4, mec = 'k', mew = 1)

sca(ax_di)
xlabel('time (h)')
ylabel('delta vs WG (‰, dual-inlet)')
grid(alpha = .2)
for k,i in enumerate(ISO_COLORS):
	if k > 0:
		for b in blocks:
			X = b['_t']
			Y = b['_d'+i+'_di']
			plot(X, Y, '+', ms = 4, mec = ISO_COLORS[i], mew = 1)

			X = b['rejected_t']
			Y = b['rejected_d'+i+'_di']
			plot(X, Y, 'x', ms = 4, mec = 'k', mew = 1, zorder = -100)

	for b in blocks:
		if b['Sample'] != 'WG':
			X = b['_t']
			Y = (log(1+b['_d627_di']/1e3) - 0.528*log(1+b['_d628_di']/1e3))*1000
	# 		plot(X, Y, 's', ms = 4, mec = 'k', mew = 1)
			plot(mean(X), mean(Y), 'ks', ms = 4, mec = 'k', mew = 1)

savefig('crunched.pdf')
show()
close(fig)

for i in ISO_COLORS:
	if i != '626':
		X = [x for b in blocks if b['Sample'] == 'WG' for x in b[f'_d{i}_di']]
		print(i, stdev(X), len(X))

fig = figure(figsize = (12,6))
subplots_adjust(.07,.1,.98,.95, 0, 0.3)
ax_D627ts = subplot(3,4,1)
ax_d628ts = subplot(3,4,5)
ax_d636ts = subplot(3,4,9)
ax_D627hist = subplot(3,7,3)
ax_d628hist = subplot(3,7,10)
ax_d636hist = subplot(3,7,17)
ax_avar = subplot(1,2,2)

for name in ['crunched', 'crunched_all']:
	with open(f'{name}.csv') as fid:
		data = [l.strip().split(',') for l in fid.readlines()]
	data = [{k:float(v) if k != 'Sample' else v for k,v in zip(data[0], l)} for l in data[1:]]
	print(len(data))
	for ref in ['vswg', 'vswg_di']:
		for r in data:
			r[f'd627b_{ref}'] = ((1+r[f'd627_{ref}']/1e3)/(1+r[f'd626b_{ref}']/1e3) - 1)*1e3
			r[f'D627_{ref}'] = (log(1+r[f'd627_{ref}']/1e3) - 0.528 * log(1+r[f'd628_{ref}']/1e3)) * 1000
			r[f'D627b_{ref}'] = (log(1+r[f'd627b_{ref}']/1e3) - 0.528 * log(1+r[f'd628_{ref}']/1e3)) * 1000


	with open(f'{name}_stats.csv', 'w') as fid:
		fid.write('Sample,d626b_vswg,d626b_vswg_di,d636_vswg,d636_vswg_di,d628_vswg,d628_vswg_di,d627_vswg,d627_vswg_di,d627b_vswg,d627b_vswg_di,D627_vswg,D627_vswg_di,D627b_vswg,D627b_vswg_di')
		for r in data:
			fid.write(f'\n{r["Sample"]},{r["d626b_vswg"]:.4f},{r["d626b_vswg_di"]:.4f},{r["d636_vswg"]:.4f},{r["d636_vswg_di"]:.4f},{r["d628_vswg"]:.4f},{r["d628_vswg_di"]:.4f},{r["d627_vswg"]:.4f},{r["d627_vswg_di"]:.4f},{r["d627b_vswg"]:.4f},{r["d627b_vswg_di"]:.4f},{r["D627_vswg"]:.4f},{r["D627_vswg_di"]:.4f},{r["D627b_vswg"]:.4f},{r["D627b_vswg_di"]:.4f}')
		fid.write('\nAVG')
		for k in 'd626b_vswg,d626b_vswg_di,d636_vswg,d636_vswg_di,d628_vswg,d628_vswg_di,d627_vswg,d627_vswg_di,d627b_vswg,d627b_vswg_di,D627_vswg,D627_vswg_di,D627b_vswg,D627b_vswg_di'.split(','):
			X = [r[k] for r in data]
			fid.write(f',{mean(X):.4f}')
		fid.write('\nSD')
		for k in 'd626b_vswg,d626b_vswg_di,d636_vswg,d636_vswg_di,d628_vswg,d628_vswg_di,d627_vswg,d627_vswg_di,d627b_vswg,d627b_vswg_di,D627_vswg,D627_vswg_di,D627b_vswg,D627b_vswg_di'.split(','):
			X = [r[k] for r in data]
			fid.write(f',{stdev(X):.4f}')
		fid.write('\nN')
		for k in 'd626b_vswg,d626b_vswg_di,d636_vswg,d636_vswg_di,d628_vswg,d628_vswg_di,d627_vswg,d627_vswg_di,d627b_vswg,d627b_vswg_di,D627_vswg,D627_vswg_di,D627b_vswg,D627b_vswg_di'.split(','):
			X = [r[k] for r in data]
			fid.write(f',{len(X):.0f}')
	if name == 'crunched':
	
		X = array([r[f'D627_{ref}'] for r in data])
		sca(ax_D627hist)
		hist(
			1e3*(X-X.mean()),
			bins = linspace(-18,18, 12+1),
			weights = ones(X.shape)/sqrt(X.size),
			histtype = 'step',
			lw = 2,
			color = 'm' if name == 'crunched' else (0,0,0,.25),
			orientation = 'horizontal',
			)

		ymin, ymax = axis()[-2:]

		sca(ax_D627ts)
		plot(
			linspace(0,1,X.size),
			(X-X.mean())*1e3,
			lw = 2 if name == 'crunched' else 1,
			color = 'm' if name == 'crunched' else (0,0,0,.25),
			zorder = 100 if name == 'crunched' else 0,
			)
		title(f'Δ$^{{17}}$O = {X.mean():.3f} ‰ (SD = {stdev(X)*1000:.1f} ppm)')
		axis([None, None, ymin, ymax])

		X = array([r[f'd628_{ref}'] for r in data])
		sca(ax_d628hist)
		hist(
			1e3*(X-X.mean()),
			bins = linspace(-18,18, 12+1),
			weights = ones(X.shape)/sqrt(X.size),
			histtype = 'step',
			color = 'r' if name == 'crunched' else (0,0,0,.25),
			lw = 2,
			orientation = 'horizontal',
			)

		ymin, ymax = axis()[-2:]

		sca(ax_d628ts)
		plot(
			linspace(0,1,X.size),
			(X-X.mean())*1e3,
			lw = 2 if name == 'crunched' else 1,
			color = 'r' if name == 'crunched' else (0,0,0,.25),
			zorder = 100 if name == 'crunched' else 0,
			)
		title(f'δ$^{{18}}$O = {X.mean():.3f} ‰ (SD = {stdev(X)*1000:.1f} ppm)')
		axis([None, None, ymin, ymax])

		X = array([r[f'd636_{ref}'] for r in data])
		sca(ax_d636hist)
		hist(
			1e3*(X-X.mean()),
			bins = linspace(-18,18, 12+1),
			weights = ones(X.shape)/sqrt(X.size),
			histtype = 'step',
			color = 'g' if name == 'crunched' else (0,0,0,.25),
			lw = 2,
			orientation = 'horizontal',
			)

		ymin, ymax = axis()[-2:]

		sca(ax_d636ts)
		plot(
			linspace(0,1,X.size),
			(X-X.mean())*1e3,
			lw = 2 if name == 'crunched' else 1,
			color = 'g' if name == 'crunched' else (0,0,0,.25),
			zorder = 100 if name == 'crunched' else 0,
			)
		title(f'δ$^{{13}}$C = {X.mean():.3f} ‰ (SD = {stdev(X)*1000:.1f} ppm)')
		axis([None, None, ymin, ymax])

		ax = ax_avar
		sca(ax)
		
		X = array([r[f'd636_vswg_di'] for r in data]) * 1000
		(tau, ad, ade, ns) = adev(X, data_type = 'freq', taus = 'all')
		plot( tau, ad, '-', color = (0,.7,0), lw = 1, label='δ$^{13}$C' )

		X = array([r[f'd628_vswg_di'] for r in data]) * 1000
		(tau, ad, ade, ns) = adev(X, data_type = 'freq', taus = 'all')
		plot( tau, ad, '-', color = (.7,0,0), lw = 1, label='δ$^{18}$O' )

		X = array([r[f'd627_vswg_di'] for r in data]) * 1000
		(tau, ad, ade, ns) = adev(X, data_type = 'freq', taus = 'all')
		plot( tau, ad, '-', color = (.7,0,.7), lw = 1, label='δ$^{17}$O' )

		X = array([r[f'D627_vswg_di'] for r in data]) * 1000
		(tau, ad, ade, ns) = adev(X, data_type = 'freq', taus = 'all')
		plot( tau, ad, '-', color = (.7,0,.7), lw = 2, label='Δ$^{17}$O' )

		ax.set_xscale('log')
		ax.set_yscale('log')

		xxyy = axis()
		plot([tau[0],tau[-1]], [ad[0], ad[0]*(tau[0]/tau[-1])**.5], 'k-', lw = 0.75, dashes = (6,3,2,3))
		axis(xxyy)

		legend()
		xlabel('Number of aliquots')
		ylabel('Allan deviation (ppm)')

		ax.xaxis.set_major_formatter(ticker.StrMethodFormatter('{x:.0f}'))
		ax.yaxis.set_major_formatter(ticker.StrMethodFormatter('{x:.0f}'))
		ax.xaxis.set_minor_formatter(ticker.StrMethodFormatter(''))
		ax.yaxis.set_minor_formatter(ticker.StrMethodFormatter(''))
		ax.set_xticks([1,2,4,8,12,20])
		ax.set_yticks([1,2,4,8])
		ax.set_ylim(.4, None)
		grid(alpha = .5)
		

for ax in [ax_D627hist, ax_d628hist, ax_d636hist]:
	sca(ax)
	xticks([])
	yticks([])

sca(ax_D627ts)
xticks([])
ylabel('Δ$^{17}$O residuals (ppm)')
grid(alpha = .75)

sca(ax_d628ts)
xticks([])
ylabel('δ$^{18}$O residuals (ppm)')
grid(alpha = .75)

sca(ax_d636ts)
xticks([])
ylabel('δ$^{13}$C residuals (ppm)')
grid(alpha = .75)

savefig('histo.pdf')
show()
close(fig)